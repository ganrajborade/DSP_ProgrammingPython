import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = [-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10]
x = []
for i in range(0,10):
	x.append(0)
for j in range(10,21):
	x.append (((0.95)**(j-10))/2)
#print(x)
from array import *
y = []
for k in range(21):
	y.append(x[20-k])

#print(y)
ax.axhline(y=0, xmin=0, xmax=1, color='k')
ax.axvline(x=0, ymin=0, ymax=1, color='k')
plt.step(xr,x,'k',where = 'post')
plt.step(xr,y,'k',where='pre')
plt.text(10,0.004,'x-axis',fontsize=18)
plt.text(0.09,0.52,'y-axis',fontsize=18)
plt.annotate("", xy=(0, 0.524), xytext=(0, 0), arrowprops=dict(arrowstyle="->"),fontsize=30)
plt.annotate("", xy=(11, 0), xytext=(0, 0), arrowprops=dict(arrowstyle="->"),fontsize=30)           
plt.grid()
black_patch = mpatches.Patch(color='black', label='$(y[n]=0.95^n u[n]  (+ or -)  (1/0.95^n) u[-n])/2$')
plt.legend(handles=[black_patch])
plt.ylabel('y[n]')
plt.xlabel('xr')



# plt.step(xr,y,'r',where='post')	
# red_patch = mpatches.Patch(color='red',label = '$y[n]=x[-n]$')
# plt.legend(handles=[red_patch])
# plt.ylabel('y[n]')
# plt.xlabel('xr')
# plt.grid()


plt.show()
