import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
xr = np.linspace(-5,5,11)
x = np.empty([11])
# empty = np.zeros(10)
for i in range(11):
	x[i] = random()
# mixed = np.concatenate((empty,x))
fig, ax = plt.subplots()

print(x)
# print(mixed)
# print(mixed[0])

ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
#ax.axhline(y=0, xmin=0.0, xmax=1.0, color='r')
y = np.empty([11])
#plotting x[n-d]:
def ideal_delay_function(d):
	for i in range(0,d):
		y[d] = 0
	for j in range(d,11):
		y[j] = x[j-d]
	return y
ax.plot(xr,ideal_delay_function(1),label= 'y[n] = x[n-1]')
ax.plot(xr,ideal_delay_function(2),label= 'y[n] = x[n-2]')
ax.plot(xr,x,label = 'x[n]')
#plt.annotate("d", xy=(0, 0.2985), xytext=(0, 0),fontsize=18)
plt.legend()
ax.set_xlabel('xr')
ax.set_ylabel('Both are present x[n] and y[n]')
plt.grid()
plt.show()
