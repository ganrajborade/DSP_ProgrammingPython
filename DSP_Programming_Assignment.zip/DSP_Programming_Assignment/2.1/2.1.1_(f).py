import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
xr = np.linspace(-5,5,11)
x = np.empty([11])
for i in range(0,4):
	x[i] = -random()
for j in range(4,11):
	x[j] = random()
y = np.empty([11])
def ideal_delay_function(d):
	for i in range(0,d):
		y[d] = 0
	for j in range(d,11):
		y[j] = x[j-d]
	return y

#Below also same function in different way:(basicaaly addition of delay functions)
s = np.zeros([11])
s[0] = x[0]/11
for c in range(1,11):
	for d in range(c+1):
		s[c] = s[c]+x[d]
	s[c] = s[c]/11
#s is the mean average values according to function given in the problem.	
print(s)
# z=0
# for i in range(11):
# 	z = z + x[i]
#print(z/11)
#print((x[0]+x[1]+x[2])/11)

ax.plot(xr,s,label= 's[n] = (x[n]+x[n-1]+....+x[n-10])/11')
ax.plot(xr,x,label = 'x[n]')
for m in range(11):
	ax.plot(xr[m],s[m],'o')

ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
#plt.annotate("d", xy=(0, 0.2985), xytext=(0, 0),fontsize=18)
plt.legend()
ax.set_xlabel('xr')
ax.set_ylabel('Both are present x[n] and s[n]')
plt.grid()
plt.show()
