import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = [-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10]
x = []
for i in range(0,10):
	x.append(0)
for j in range(10,21):
	x.append ((0.95)**(j-10))
print(x)
from array import *
y = []
for k in range(21):
	y.append(x[20-k])

print(y)
#ax.axvline(x=0, ymin=0.05, ymax=0.95, color='r')

subplot(1,2,1)
plt.step(xr,x,'b',where='post')
plt.grid()
blue_patch = mpatches.Patch(color='blue', label='$x[n]=0.95^n u[n]$')
plt.legend(handles=[blue_patch])
plt.ylabel('x[n]')
plt.xlabel('xr')

subplot(1,2,2)

plt.step(xr,y,'r',where='pre')	
red_patch = mpatches.Patch(color='red',label = '$y[n]=x[-n]$')
plt.legend(handles=[red_patch])
plt.ylabel('y[n]')
plt.xlabel('xr')
plt.grid()


plt.show()
