import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
xr = np.linspace(-5,5,11)
###  Defining the function (0.95^n)u[n]:
x = np.empty(11)
for i in range(0,5):
	x[i] = 0
for j in range(5,11):
	x[j] =(0.95)**(j-5)
print(x)
y = np.empty([11])
def ideal_delay_function(d):
	for i in range(0,d):
		y[d] = 0
	for j in range(d,11):
		y[j] = x[j-d]
	return y
print(ideal_delay_function(1))

z1 = x - 2*ideal_delay_function(1) + ideal_delay_function(2)
print(z1[3])
print(x[3]-2*x[2]+x[1])
#ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
subplot(1,2,1)
plt.step(xr,x,where = 'post',label = '$x[n]=0.95^n u[n]$')
plt.step(xr,ideal_delay_function(1),where = 'post',label= 'x[n-1]')
plt.step(xr,ideal_delay_function(2),where = 'post',label= 'x[n-2]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('x[n],x[n-1] and x[n-2] are present in this subplot')
plt.grid()
subplot(1,2,2)
plt.step(xr,z1,'k',where = 'post',label = 'z[n] = x[n]-2x[n-1]+x[n-2]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('z[n]')
plt.grid()
plt.show()