import numpy as np 
from random import random
import matplotlib.pyplot as plt

#Taking 11 samples for simplicity
xr = np.linspace(-10,10,11)
x = np.empty([1,11])
for i in range(11):
	x[0,i] = random()
fig, ax = plt.subplots()
print(xr/2)
print((x[0,0]+x[0,10])/2)
ax.plot(xr,x[0,:],label = 'x[n]')
ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
#ax.axhline(y=0, xmin=0.0, xmax=1.0, color='r')
y = np.empty([1,11])
for i in range(11):
	y[0,i] = (x[0,10-i] + x[0,i])/2
print(y)
ax.plot(xr,y[0,:],label= 'y[n] = Xe[n] i.e y[n] = (x[n]+x[-n])/2 ')
plt.legend()
ax.set_xlabel('xr')
ax.set_ylabel('Both are present x[n] and y[n]')
plt.grid()
plt.show()
