import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = np.linspace(-5,5,11)
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
###  Defining the function (0.95^n)u[n]:
x = np.empty(11)
for i in range(0,5):
	x[i] = 0
for j in range(5,11):
	x[j] =(0.95)**(j-5)
print(x)

y = np.zeros([11])
y[0] = x[0]/11
for c in range(1,11):
	for d in range(c+1):
		y[c] = y[c]+x[d]
	y[c] = y[c]/11
print(y)
print(y[8])
print((x[0]+x[1]+x[2]+x[3]+x[4]+x[5]+x[6]+x[7]+x[8])/11)
subplot(1,2,1)
plt.step(xr,x,where= 'post',label = '$x[n]=0.95^n u[n]$')
plt.legend()
plt.xlabel('xr')
plt.ylabel('x[n]')
plt.grid()
subplot(1,2,2)
plt.step(xr,y,'k',where = 'post',label= 'y[n] = (x[n]+x[n-1]+....+x[n-10])/11')
for m in range(11):
	plt.plot(xr[m],y[m],'o')
plt.legend()
plt.xlabel('xr')
plt.ylabel('y[n]')
plt.grid()
plt.show()