import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = np.linspace(-5,5,11)
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
###  Defining the function (0.95^n)u[n]:
x = np.empty(11)
for i in range(0,5):
	x[i] = 0
for j in range(5,11):
	x[j] =(0.95)**(j-5)
print(x)
y = np.empty([11])
def ideal_delay_function(d):
	for i in range(0,d):
		y[d] = 0
	for j in range(d,11):
		y[j] = x[j-d]
	return y
print(ideal_delay_function(1))
z = x - ideal_delay_function(1)
#ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
subplot(1,2,1)
plt.step(xr,x,where='post',label = '$x[n]=0.95^n u[n]$')
plt.step(xr,ideal_delay_function(1),where='post',label= 'y[n] = x[n-1]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('Both are present x[n] and y[n]')
plt.grid()
subplot(1,2,2)
plt.step(xr,z,'g',where='post',label = 'z[n] = x[n]-x[n-1]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('z[n]')
plt.grid()
plt.show()
