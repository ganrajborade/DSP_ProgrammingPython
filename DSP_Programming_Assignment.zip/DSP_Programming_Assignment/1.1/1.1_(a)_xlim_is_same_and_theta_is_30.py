import numpy as np 
import matplotlib.pyplot as plt 

fo = [1/8,2/8,3/8,3.5/8,4/8,5/8,6/8,7/8]

x = np.empty([8,50])
y = np.empty([8,50])

fig, ax = plt.subplots(2, 4)
fig.subplots_adjust(hspace=0.4, wspace=0.4)
for i in range(0,8):
	for j in range(0,50):
		x[i,j] = (fo[i])*j
		y[i,j] = np.sin((2*np.pi*x[i,j])+30)	


for n in range(0,4):
	ax[0,n].plot(x[n,:],y[n,:],'b')
	ax[0,n].set_xlim([0,6])
ax[1,0].plot(x[4,:],y[4,:],'b')
ax[1,0].set_ylim([-1,1])
ax[1,0].set_xlim([0,6])
for m in range(1,4):
	ax[1,m].plot(x[4+m,:],y[4+m,:],'r')
	ax[1,m].set_xlim([0,6])

ax[0,0].set_title('Fo(Original frequency of sinusoid) = '+str(1))
ax[0,0].set_xlabel('n/8')
ax[0,0].set_ylabel('$y = sin(2\pi n/8)$')


ax[0,1].set_title('Fo(Original frequency of sinusoid) = '+str(2))
ax[0,1].set_xlabel('2n/8')
ax[0,1].set_ylabel('$y = sin(2\pi 2(n)/8)$')


ax[0,2].set_title('Fo(Original frequency of sinusoid) = '+str(3))
ax[0,2].set_xlabel('3n/8')
ax[0,2].set_ylabel('$y = sin(2\pi 3(n)/8)$')


ax[0,3].set_title('Fo(Original frequency of sinusoid) = '+str(3.5))
ax[0,3].set_xlabel('(3.5)n/8')
ax[0,3].set_ylabel('$y = sin(2\pi (3.5)(n)/8)$')



ax[1,0].set_title('Fo(Original frequency of sinusoid) = '+str(4))
ax[1,0].set_xlabel('4n/8')
ax[1,0].set_ylabel('$y = sin(2\pi 4n/8)$')


ax[1,1].set_title('Fo(Original frequency of sinusoid) = '+str(5))
ax[1,1].set_xlabel('5n/8')
ax[1,1].set_ylabel('$y = sin(2\pi 5n/8)$')


ax[1,2].set_title('Fo(Original frequency of sinusoid) = '+str(6))
ax[1,2].set_xlabel('6n/8')
ax[1,2].set_ylabel('$y = sin(2\pi 6n/8)$')


ax[1,3].set_title('Fo(Original frequency of sinusoid) = '+str(7))
ax[1,3].set_xlabel('7n/8')
ax[1,3].set_ylabel('$y = sin(2\pi 7n/8)$')

plt.show()