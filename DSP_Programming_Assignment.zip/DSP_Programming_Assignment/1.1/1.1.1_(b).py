import soundfile as sf
from scipy import signal

import librosa    

#I have recorded my_voice.wav at 16kHz sampling rate.Therefore I am downsampling it by 2 at each point upto 1kHz.
y, s = librosa.load('my_voice.wav', sr=None) # Downsample 16kHz to 8kHz
print(s)

y1, s1 = librosa.load('my_voice.wav', sr=8000) # Downsample 16kHz to 8kHz
sf.write('sampling_at_8kHz.wav',y1,s1)

y2, s2 = librosa.load('my_voice.wav', sr=4000) # Downsample 16kHz to 4kHz
sf.write('sampling_at_4kHz.wav',y2,s2)

y3, s3 = librosa.load('my_voice.wav', sr=2000) # Downsample 16kHz to 2kHz
sf.write('sampling_at_2kHz.wav',y3,s3)

y4, s4 = librosa.load('my_voice.wav', sr=1000) # Downsample 16kHz to 1kHz
sf.write('sampling_at_1kHz.wav',y4,s4)

#Sampling at higher frequency than speech sampling frequency.
y5, s5 = librosa.load('my_voice.wav', sr=32000)
sf.write('sampling_at_32kHz.wav',y5,s5)

#Original Speech Signal
y6, s6 = librosa.load('my_voice.wav', sr=16000)
sf.write('sampling_at_16kHz.wav',y6,s6)
