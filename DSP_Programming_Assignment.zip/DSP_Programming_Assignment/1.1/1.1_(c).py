import numpy as np 
import matplotlib.pyplot as plt 

fo_1 = [1/8,2/8,3/8,3.5/8,4/8,5/8,6/8,7/8]
fo_2 = [1/80,2/80,3/80,3.5/80,4/80,5/80,6/80,7/80]
x1 = np.empty([8,100])
x2 = np.empty([8,100])
y1 = np.empty([8,100])
y2 = np.empty([8,100])

fig, ax = plt.subplots(2, 4)
fig.subplots_adjust(hspace=0.4, wspace=0.4)
for i in range(0,8):
	for j in range(0,100):
		x1[i,j] = (fo_1[i])*j
		x2[i,j] = (fo_2[i])*j
		y1[i,j] = np.sin((2*np.pi*x1[i,j])+30)	
		y2[i,j] = np.sin((2*np.pi*x2[i,j])+30)	

for n in range(0,4):
	ax[0,n].plot(x1[n,:],y1[n,:],'b')
	ax[0,n].plot(x2[n,:],y2[n,:],'m')
	ax[0,n].set_xlim([0,1.2])
ax[1,0].plot(x1[4,:],y1[4,:],'b')
ax[1,0].plot(x2[4,:],y2[4,:],'m')
# ax[1,0].set_ylim([-1,1])
ax[1,0].set_xlim([0,1.2])
ax[1,1].set_xlim([0,1.2])
ax[1,2].set_xlim([0,1.2])
ax[1,3].set_xlim([0,1.2])
for m in range(1,4):
	ax[1,m].plot(x1[4+m,:],y1[4+m,:],'r')
	ax[1,m].plot(x2[4+m,:],y2[4+m,:],'c')
    


ax[0,0].set_title('Fo(Original frequency of sinusoid) = '+str(1))
ax[0,0].set_xlabel('n/8')
ax[0,0].set_ylabel('$y = sin(2\pi n/8)$')


ax[0,1].set_title('Fo(Original frequency of sinusoid) = '+str(2))
ax[0,1].set_xlabel('2n/8')
ax[0,1].set_ylabel('$y = sin(2\pi 2(n)/8)$')


ax[0,2].set_title('Fo(Original frequency of sinusoid) = '+str(3))
ax[0,2].set_xlabel('3n/8')
ax[0,2].set_ylabel('$y = sin(2\pi 3(n)/8)$')


ax[0,3].set_title('Fo(Original frequency of sinusoid) = '+str(3.5))
ax[0,3].set_xlabel('(3.5)n/8')
ax[0,3].set_ylabel('$y = sin(2\pi (3.5)(n)/8)$')



ax[1,0].set_title('Fo(Original frequency of sinusoid) = '+str(4))
ax[1,0].set_xlabel('4n/8')
ax[1,0].set_ylabel('$y = sin(2\pi 4n/8)$')


ax[1,1].set_title('Fo(Original frequency of sinusoid) = '+str(5))
ax[1,1].set_xlabel('5n/8')
ax[1,1].set_ylabel('$y = sin(2\pi 5n/8)$')


ax[1,2].set_title('Fo(Original frequency of sinusoid) = '+str(6))
ax[1,2].set_xlabel('6n/8')
ax[1,2].set_ylabel('$y = sin(2\pi 6n/8)$')


ax[1,3].set_title('Fo(Original frequency of sinusoid) = '+str(7))
ax[1,3].set_xlabel('7n/8')
ax[1,3].set_ylabel('$y = sin(2\pi 7n/8)$')

plt.show()