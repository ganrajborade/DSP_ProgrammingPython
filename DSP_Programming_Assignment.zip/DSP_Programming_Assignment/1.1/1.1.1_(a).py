import soundfile as sf
from scipy import signal

import librosa    
y, s = librosa.load('audio_sample.wav',sr = None) 
print(s) #Checking sampling rate

y1, s1 = librosa.load('audio_sample.wav', sr=32000) 
sf.write('audio_sampled_at_32kHz.wav',y1,s1)
print("Sampling at "+str(s1))

y2, s2 = librosa.load('audio_sample.wav', sr=16000) 
sf.write('audio_sampled_at_16kHz.wav',y2,s2)
print("Sampling at "+str(s2))

y3, s3 = librosa.load('audio_sample.wav', sr=8000) 
sf.write('audio_sampled_at_8kHz.wav',y3,s3)
print("Sampling at "+str(s3))

y4, s4 = librosa.load('audio_sample.wav', sr=4000) 
sf.write('audio_sampled_at_4kHz.wav',y4,s4)
print("Sampling at "+str(s4))

y5, s5 = librosa.load('audio_sample.wav', sr=2000) 
sf.write('audio_sampled_at_2kHz.wav',y5,s5)
print("Sampling at "+str(s5))

y6, s6 = librosa.load('audio_sample.wav', sr=1000) 
sf.write('audio_sampled_at_1kHz.wav',y6,s6)
print("Sampling at "+str(s6))


