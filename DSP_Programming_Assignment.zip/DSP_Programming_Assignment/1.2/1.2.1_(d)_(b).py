import numpy as np
# import matplotlib.pyplot as plt
import soundfile as sf
from scipy import signal
import librosa

def quantize(x,N):
	a = np.min(x) 
	b = np.max(x) 
	length = len(x)
	Xq = np.empty(length)
	for i in range(length):
		Xq[i] = (np.round(((x[i]-a)/(b-a))*(2**N - 1))*((b-a)/(2**N -1))) + a
	return Xq

y, s = librosa.load('audio_sample.wav',sr = None) 
# print(y)
# print(len(y))
# print(np.max(y))
# print(np.min(y))

y_q1 = quantize(y,3)
sf.write('audio_sample_quantized_at_3bit_per_sample.wav',y_q1,s)

y_q2 = quantize(y,2)
sf.write('audio_sample_quantized_at_2bit_per_sample.wav',y_q2,s)

y_q3 = quantize(y,1)
sf.write('audio_sample_quantized_at_1bit_per_sample.wav',y_q3,s)
# print(y_q3)
# print(y_q2)