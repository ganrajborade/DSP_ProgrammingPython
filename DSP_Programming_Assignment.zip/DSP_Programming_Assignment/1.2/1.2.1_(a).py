import numpy as np
import matplotlib.pyplot as plt
#Lets define the range of input signal to be : min(x[n]) <= x[n] <= max(x[n])

def quantize(x,N):
	a = np.min(x) 
	b = np.max(x) 
	length = len(x)
	Xq = np.empty(length)
	for i in range(length):
		Xq[i] = (np.round(((x[i]-a)/(b-a))*(2**N - 1))*((b-a)/(2**N -1))) + a
	return Xq


#Testing is done and the function is working properly for the below case

'''
x1 = np.linspace(0,2*np.pi,100)
y1 = np.sin(x1)
#print(y1)

N = 6
y = quantize(y1,N)
plt.plot(x1,y)
plt.show()

'''

