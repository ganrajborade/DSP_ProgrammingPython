import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
from scipy import signal
import librosa
import matplotlib.patches as mpatches
from pylab import *
def quantize(x,N):
	a = np.min(x) 
	b = np.max(x) 
	length = len(x)
	Xq = np.empty(length)
	for i in range(length):
		Xq[i] = (np.round(((x[i]-a)/(b-a))*(2**N - 1))*((b-a)/(2**N -1))) + a
	return Xq

y, s = librosa.load('audio_sample.wav',sr = None) 
x = np.linspace(0,len(y),len(y))
y_q3 = quantize(y,3)
y_q2 = quantize(y,2)
y_q1 = quantize(y,1)

y_diff_1 = (y - y_q1)
#print(y_diff_1)
y_diff_2 = (y - y_q2)
y_diff_3 = (y - y_q3)
sf.write('difference_of_original_and_quantized_signal_for_3bit_quantized_signal.wav',y_diff_3,s)
sf.write('difference_of_original_and_quantized_signal_for_2bit_quantized_signal.wav',y_diff_2,s)
sf.write('difference_of_original_and_quantized_signal_for_1bit_quantized_signal.wav',y_diff_1,s)

subplot(1,3,1)
plot(x,y_diff_1,'r')
plt.grid()
plt.xlim(0,75)
plt.xlabel('x')
plt.ylabel('y_diff_1 (Difference of y and y_q1)')
red_patch = mpatches.Patch(color='red', label='y(original) - y(quantized at 1-bit/sample)')
plt.legend(handles=[red_patch])
# subplots_adjust(right = 1)
subplot(1,3,2)
plot(x,y_diff_2,'b')
plt.grid()
plt.xlim(0,75)
plt.xlabel('x')
plt.ylabel('y_diff_2 (Difference of y and y_q2)')
blue_patch = mpatches.Patch(color='blue', label='y(original) - y(quantized at 2-bit/sample)')
plt.legend(handles=[blue_patch])

subplot(1,3,3)
plot(x,y_diff_3,'g')
plt.xlim(0,75)
plt.xlabel('x')
plt.ylabel('y_diff_3 (Difference of y and y_q3)')
green_patch = mpatches.Patch(color='green', label='y(original) - y(quantized at 3-bit/sample)')
plt.legend(handles=[green_patch])

plt.grid()
plt.show()


#Actually the xlim will lie upto len(y) but I have taken xlim as 200 for seeing visually. 