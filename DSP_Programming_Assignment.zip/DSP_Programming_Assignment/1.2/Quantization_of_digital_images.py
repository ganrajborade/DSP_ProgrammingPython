import numpy as np 
import cv2


def quantize(x,N):
	a = 0 
	b = 255
	length = len(x)
	Xq = np.empty(length)
	for i in range(length):
		Xq[i] = (np.round(((x[i]-a)/(b-a))*(2**N - 1))*((b-a)/(2**N -1))) + a
	return Xq

img = cv2.imread('einstein.jpg',0)

N1 = 64
N2 = 32
N3 = 16
N4 = 8
N5 = 4
N6 = 2
N7 = 1
# print(img)
# print(np.max(img))
# print(np.min(img))
# print(img.shape)

quantized_image1 = np.empty([182,186])
quantized_image2 = np.empty([182,186])
quantized_image3 = np.empty([182,186])
quantized_image4 = np.empty([182,186])
quantized_image5 = np.empty([182,186])
quantized_image6 = np.empty([182,186])
quantized_image7 = np.empty([182,186])
for i in range(182):
    quantized_image1[i,:] = quantize(img[i,:],N1)
    quantized_image2[i,:] = quantize(img[i,:],N2)
    quantized_image3[i,:] = quantize(img[i,:],N3)
    quantized_image4[i,:] = quantize(img[i,:],N4)
    quantized_image5[i,:] = quantize(img[i,:],N5)
    quantized_image6[i,:] = quantize(img[i,:],N6)
    quantized_image7[i,:] = quantize(img[i,:],N7)
#print(quantized_image[0,:])


cv2.imshow('Einstein_at_N=64',quantized_image1)
cv2.imshow('Einstein_at_N=32',quantized_image2)
cv2.imshow('Einstein_at_N=16',quantized_image3)
cv2.imshow('Einstein_at_N=8',quantized_image4)
cv2.imshow('Einstein_at_N=4',quantized_image5)
cv2.imshow('Einstein_at_N=2',quantized_image6)
cv2.imshow('Einstein_at_N=1',quantized_image7)

cv2.waitKey(0)
cv2.destroyAllWindows()