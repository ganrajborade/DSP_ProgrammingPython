import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
from scipy import signal
import librosa
import matplotlib.patches as mpatches


def quantize(x,N):
	a = np.min(x) 
	b = np.max(x) 
	length = len(x)
	Xq = np.empty(length)
	for i in range(length):
		Xq[i] = (np.round(((x[i]-a)/(b-a))*(2**N - 1))*((b-a)/(2**N -1))) + a
	return Xq

y, s = librosa.load('audio_sample.wav',sr = None) 
x = np.linspace(0,len(y),len(y))

y_q2 = quantize(y,4)

y_diff = (y - y_q2)
sf.write('difference_of_original_and_quantized_signal.wav',y_diff,s)
plt.plot(x,y_diff,'r')
plt.xlim(0,200)
plt.xlabel('x')
red_patch = mpatches.Patch(color='red', label='Difference between the original audio file, and quantized audio file ')
plt.legend(handles=[red_patch])



plt.ylabel('y_diff (Difference of y and y_q2)')
plt.grid()
plt.show()

#Actually the xlim will lie upto len(y) but I have taken xlim as 200 for seeing visually. 