import numpy as np
import librosa
import soundfile as sf
input_signal, s = librosa.load('audio_sample.wav',sr = None) 

gaussian_noise = np.random.normal(0,1,len(input_signal))/20
mixed= input_signal + gaussian_noise
#print(mixed)
empty = np.zeros(50)

# scaled_Gaussian_Noise = np.int16(gaussian_noise/np.max(np.abs(gaussian_noise))*20000)
# sf.write('DSP_Sound_GaussianNoise_Mean.wav',scaled_Gaussian_Noise,44100)

scaled_AddedGaussian_Noise = np.int16(mixed/np.max(np.abs(mixed))*20000)
sf.write('GaussianNoise_Added(MedianFiltering).wav',scaled_AddedGaussian_Noise,44100)
scaled_original=np.int16(input_signal/np.max(np.abs(input_signal))*35000)
sf.write('Original_Sound(Scaled)(Median).wav',scaled_original,44100)
mixed1 = np.concatenate((empty,scaled_AddedGaussian_Noise))

band_gap = np.linspace(-50,50,50,dtype = 'int')
#Median Filtering:
filtered_signal = np.zeros(1)
for i in range(len(input_signal)):
	median = 0
	median = np.median(mixed1[np.array(i+band_gap)])
	filtered_signal = np.append(filtered_signal,median)
scaled_filtered = np.int16(filtered_signal/np.max(np.abs(filtered_signal))*35000)
sf.write('Filtered_Sound(MedianFiltering).wav',scaled_filtered,44100)
'''
A median filter is a nonlinear filter used for signal smoothing. It is particularly good for removing impulsive type noise from a signal.       
'''