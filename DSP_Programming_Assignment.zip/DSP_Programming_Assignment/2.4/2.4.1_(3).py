import numpy as np
import librosa
import soundfile as sf


input_signal, s = librosa.load('audio_sample.wav',sr = None) 
gaussian_noise = np.random.normal(0,1,len(input_signal))/20
mixed= input_signal + gaussian_noise

empty = np.zeros(50)



scaled_AddedGaussian_Noise = np.int16(mixed/np.max(np.abs(mixed))*35000)

scaled_original=np.int16(input_signal/np.max(np.abs(input_signal))*35000)

mixed1 = np.concatenate((empty,scaled_AddedGaussian_Noise))

band_gap = np.linspace(-50,50,50,dtype = 'int')
#Mean Filtering:
filtered_signal1 = np.zeros(1)
for i in range(len(input_signal)):
	mean = 0
	mean = np.mean(mixed1[np.array(i+band_gap)])
	filtered_signal1 = np.append(filtered_signal1,mean)
scaled_filtered1 = np.int16(filtered_signal1/np.max(np.abs(filtered_signal1))*35000)
#Median Filtering:
filtered_signal2 = np.zeros(1)
for j in range(len(input_signal)):
	median = 0
	median = np.median(mixed1[np.array(j+band_gap)])
	filtered_signal2 = np.append(filtered_signal1,median)
scaled_filtered2 = np.int16(filtered_signal2/np.max(np.abs(filtered_signal2))*35000)


import numpy as np 
def signaltonoise(a, axis, ddof): 
    a = np.asanyarray(a) 
    m = a.mean(axis) 
    sd = a.std(axis = axis, ddof = ddof) 
    return np.where(sd == 0, 0, m / sd) 


print ("\nsignaltonoise ratio for scaled_filtered1(Mean Filtering) : ",  
       signaltonoise(scaled_filtered1, axis = 0, ddof = 0))  

print ("\nsignaltonoise ratio for scaled_filtered2(Mean Filtering) : ",  
       signaltonoise(scaled_filtered2, axis = 0, ddof = 0))  