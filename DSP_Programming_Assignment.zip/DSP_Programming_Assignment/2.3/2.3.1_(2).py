import numpy as np
import librosa
import soundfile as sf
import matplotlib.pyplot as plt
from random import random
fig, ax = plt.subplots()

x, s = librosa.load('my_voice.wav',sr = None) 
xr = np.linspace(0,len(x),len(x))
print(len(x))
gaussian_noise = np.random.normal(0,0.25,len(x))
print(gaussian_noise[0])
r = np.zeros(len(x))
r[0] = gaussian_noise[0]*x[0]
for c in range(1,len(x)):
	for d in range(c+1):
		r[c] = r[c]+(gaussian_noise[d]*x[d])

sf.write('reverberated_signal_having_impulse_response_uniformly_distributed_noise.wav',r,44100)
ax.plot(xr,r,label= 'r[n] = Summation of ak(x[n-dk]) with k ranging from 0 to 99')
ax.plot(xr,x,label = 'x[n]')
ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
#plt.annotate("d", xy=(0, 0.2985), xytext=(0, 0),fontsize=18)
plt.legend()
ax.set_xlabel('xr')
ax.set_ylabel('Both are present x[n] and r[n]')
plt.grid()
plt.show()

