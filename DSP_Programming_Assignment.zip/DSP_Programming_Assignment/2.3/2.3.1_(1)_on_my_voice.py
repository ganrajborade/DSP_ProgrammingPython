import numpy as np 
from random import random
import soundfile as sf
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
import librosa
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
x, s = librosa.load('my_voice.wav',sr = None) 
xr = np.linspace(0,len(x),len(x))

r = np.zeros(len(x))
h = np.empty([len(x)])
for j in range(len(x)):
	h[j] = (0.999)**j
def ideal_delay_function(d):
	for i in range(0,d):
		y[d] = 0
	for j in range(d,11):
		y[j] = x[j-d]
	return y

#Below also same function in different way:(basically addition of delay functions)
#d0 =0 ,d1 = 1,d2 = 2,......

r[0] = h[0]*x[0]
for c in range(1,len(x)):
	for d in range(c+1):
		r[c] = r[c]+(h[d]*x[d])

#s is a reverberated signal		
print(r)
sf.write('reverberated_signal_having_impulse_response_given_in_question_withmy_voice.wav',r,44100)

ax.plot(xr,r,label= 'r[n] = Summation of ak(x[n-dk]) with k ranging from 0 to 99')
ax.plot(xr,x,label = 'x[n]')
ax.axvline(x=0, ymin=0.0, ymax=1.0, color='r')
#plt.annotate("d", xy=(0, 0.2985), xytext=(0, 0),fontsize=18)
plt.legend()
ax.set_xlabel('xr')
ax.set_ylabel('Both are present x[n] and r[n]')
plt.grid()
plt.show()
