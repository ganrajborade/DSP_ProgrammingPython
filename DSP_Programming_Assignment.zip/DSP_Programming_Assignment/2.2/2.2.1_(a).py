import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = np.linspace(-100,100,201)
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
###  Defining the function (0.95^n)u[n]:
x1 = np.empty(201)
for i in range(0,100):
	x1[i] = 0
for j in range(100,201):
	x1[j] =(0.9)**(j-100)

x2 = np.empty(201)
for k in range(201):
	x2[k] = np.sin((np.pi/20)*(k-100))
#print(x1)
plt.step(xr,x1,'k',where='post',label='$x1[n] = (0.9)^n u[n]$')
plt.plot(xr,x2,'r',label='$x2[n] = sin(\pi\ /20)n$')
plt.ylabel('Both x1[n] and x2[n] are present here')
plt.xlabel('xr = n')
plt.grid()
plt.legend()
plt.show()