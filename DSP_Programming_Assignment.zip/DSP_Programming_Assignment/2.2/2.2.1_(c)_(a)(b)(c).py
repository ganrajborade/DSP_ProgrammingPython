
import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches

fig, ax = plt.subplots()
xr = np.linspace(-100,100,201)

x1 = np.empty(201)
for i in range(0,100):
	x1[i] = 0
for j in range(100,201):
	x1[j] =(0.9)**(j-100)

x2 = np.empty(201)
for k in range(201):
	x2[k] = np.sin((np.pi/20)*(k-100))
y1 = np.empty(201)
y2 = np.empty(201)
for i in range(201):
	
	y1[i] = x1[200-i]
	y2[i] = x2[200-i]

def ideal_delay_function(x,d):
	z = np.zeros(201)
	for i in range(0,d):
		z[d] = 0
	for j in range(d,201):
		z[j] = x[j-d]
	return z
def reverse_delay_function(x,d):
	z1 = np.zeros(201)
	for i in range(d):
		z1[d] = 0
	for j in range(d,201):
		z1[j] = x[100+d-j]
	return z1
d = 50
x1_d = ideal_delay_function(x1,d)
y1_d = np.zeros(201)
for k in range(201):
	y1_d[k] = x1_d[200-k]


y2_d = ideal_delay_function(y1,d)


x2_d = ideal_delay_function(x2,d)
y22_d = np.zeros(201)
for k in range(201):
	y22_d[k] = x2_d[200-k]
y23_d = ideal_delay_function(y2,d)	
subplot(2,1,1)
plt.step(xr,y1_d,label= 'x1[-n-50]')
plt.step(xr,y2_d,label='x1[-n+50]')
#I have checked only for x1[n] because in case of x2[n],it will eventually become true that this system is not time invariant.
plt.legend()
plt.xlabel('xr')
plt.ylabel('Both x1[-n-50] and x1[-n+50] are present')
plt.grid()
subplot(2,1,2)
plt.plot(xr,y22_d,label= 'x2[-n-50]')
plt.plot(xr,y23_d,label='x2[-n+50]')
#I have checked only for x1[n] because in case of x2[n],it will eventually become true that this system is not time invariant.
plt.legend()
plt.xlabel('xr')
plt.ylabel('Both x2[-n-50] and x2[-n+50] are present')
print('Since the graph of x[-n-50] and x[-n+50] is not same for both functions,hence y[n] = x[-n] is not time invarient.')
print('---------------------------------------------------------------------------------------------')
print('print("For the systems y[n]=Xe[n] and y[n]=Xo[n],since they are just equal to (x[n]+x[-n])/2 and (x[n]-x[-n])/2 respectively,and we know that y1[n] = x1[-n] is not time invariant and y1[n] = x1[n] is time invariant.Hence both the functions are not time invariant i.e Xe[n] and Xo[n] are not time invariant.")')
plt.grid()
plt.show()

