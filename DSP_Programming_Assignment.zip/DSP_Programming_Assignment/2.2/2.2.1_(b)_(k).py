#Testing linearity for y[n] = x[-n] :

import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches
#Taking 11 samples for simplicity
fig, ax = plt.subplots()
xr = np.linspace(-100,100,201)
# We are taking M = 10.
#Therefore totally on 11 values we have to perform the operation mentioned in the question. 
###  Defining the function (0.95^n)u[n]:
x1 = np.empty(201)
for i in range(0,100):
	x1[i] = 0
for j in range(100,201):
	x1[j] =(0.9)**(j-100)

x2 = np.empty(201)
for k in range(201):
	x2[k] = np.sin((np.pi/20)*(k-100))
#Choosing 2 values for a and b:
a = 2
b = 4
#print(x1)
x = np.empty(201)
for l in range(201):
	x[l] = 2*x1[l] + 4*x2[l]
y = np.empty([201])
y1 = np.empty([201])
y2 = np.empty([201])
for m in range(201):
	y1[m] = (x1[m])**2
	y2[m] = (x2[m])**2
	y[m] = (x[m])**2
subplot(4,1,1)
plt.step(xr,(x1),'k',where='post',label='$x1[n]$')
plt.step(xr,(y1),'b',where='post',label='$y1[n]=(x1[n])^2$')
#plt.step(xr,(y1),'r',where='pre',label='$y1[n]$')
plt.ylabel('x1[n] and y1[n] ')
plt.xlabel('xr = n')
plt.grid()
plt.legend()

subplot(4,1,2)
plt.plot(xr,(x2),'k',label='$x2[n]$')
plt.plot(xr,(y2),'r',label='$y2[n]=(x2[n])^2$')
plt.ylabel('x2[n] and y2[n]')
plt.xlabel('xr = n')
plt.grid()
plt.legend()
subplot(4,1,3)
#plt.plot(xr,(2*x1 + 4*x2),'k',label='$x[n] = 2x1[n]+4x2[n]$')
plt.plot(xr,(2*y1 + 4*y2),'r',label='$2y1[n]+4y2[n]$')
plt.ylabel('2y1[n]+4y2[n]')
plt.xlabel('xr = n')
plt.grid()
plt.legend()
subplot(4,1,4)
#plt.plot(xr,x,'k',label='$x[n] = 2x1[n]+4x2[n]$')
plt.plot(xr,y,'r',label='$y[n] = x[n]^2 \ where \ x[n] = 2x1[n] + 4x2[n]$')
plt.ylabel('$y[n]=x[n]^2$')
plt.xlabel('xr = n')
print("Since the plots 3 and 4 are not similiar that means 2x1[n] + 4x2[2] doesnot give 2y1[n] + 4y2[2],hence the system y[n] = x[n]^2 is not a linear system.")

plt.grid()
plt.legend()

plt.show()


