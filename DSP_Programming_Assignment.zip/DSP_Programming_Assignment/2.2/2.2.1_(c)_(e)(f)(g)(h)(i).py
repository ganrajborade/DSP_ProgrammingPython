
import numpy as np 
from random import random
import matplotlib.pyplot as plt
from pylab import *
import matplotlib.patches as mpatches

fig, ax = plt.subplots()
xr = np.linspace(-100,100,201)

x1 = np.empty(201)
for i in range(0,100):
	x1[i] = 0
for j in range(100,201):
	x1[j] =(0.9)**(j-100)

x2 = np.empty(201)
for k in range(201):
	x2[k] = np.sin((np.pi/20)*(k-100))
y1 = np.empty(201)
y2 = np.empty(201)

def ideal_delay_function(x,d):
	z = np.zeros(201)
	for i in range(0,d):
		z[d] = 0
	for j in range(d,201):
		z[j] = x[j-d]
	return z

d = 10
x1_d = ideal_delay_function(x1,d)
y1_d = ideal_delay_function((x1_d),d)
x2_d = ideal_delay_function(x2,d)
y3_d = ideal_delay_function((x2_d),d)
subplot(2,2,1)
plt.step(xr,y1_d,label= 'x1[n-2d]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('x1[n-2d]')
plt.grid()

subplot(2,2,2)
y2_d = ideal_delay_function(x1,2*d)
plt.step(xr,y2_d,'r',label='y1[n-d]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('y1[n-d]')
plt.grid()

subplot(2,2,3)
plt.plot(xr,y3_d,label= 'x2[n-2d]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('x2[n-2d]')
plt.grid()

subplot(2,2,4)
y4_d = ideal_delay_function(x2,2*d)
plt.plot(xr,y4_d,'r',label='y2[n-d]')
plt.legend()
plt.xlabel('xr')
plt.ylabel('y2[n-d]')
plt.grid()

print('Since both the curves for both functions are same thatmeans the system y[n] = x[n-d] is time invariant system.')
print("For the systems y[n]=(summation of x[n-k] from k=0 to k=M)/11 , y[n]=x[n]-x[n-1] ,y[n]=x[n]-2x[n-1]+x[n-2] and y[n] = x[n-2] + x[2-n],since they are just the combination of the concepts which we have done in the program (2.2_(c)_(1)(2)(3).py) and this program,so al the mentioned systems are time invariant.")


plt.show()

